# Smart Crop Advisor 🌱

A Core Java based crop recommendation project.

## Concepts Covered
- Basics and Scanner
- Conditional Statements
- Strings
- Methods
- Arrays
- Classes and Objects
- Encapsulation
- Inheritance
- Polymorphism
- Exception Handling

## Final Project
The `11-Final-Project` folder contains the complete Smart Crop Advisor program.

## Crops
- Rice
- Maize
- Groundnut

## Inputs
- Soil type
- Soil pH
- Nitrogen, Phosphorus, Potassium
- Temperature
- Humidity
- Rainfall
- Farm area
- Water availability
- Season
